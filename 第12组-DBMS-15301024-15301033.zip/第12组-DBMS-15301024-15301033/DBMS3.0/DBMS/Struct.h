
#ifndef ST_FONT_DEFINED
#define ST_FONT_DEFINED
typedef struct{
	CString m_FieldName;
	CString m_FieldType;
	CString m_Length;
	CString m_Hint;
	CString m_Primary;
	CString m_Null;
	CString m_Min;
	CString m_Max;
	CString m_Default;
}Field;


#endif

#pragma once