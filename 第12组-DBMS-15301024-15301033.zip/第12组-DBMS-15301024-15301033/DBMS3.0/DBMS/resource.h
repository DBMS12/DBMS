//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DBMS.rc
//
#define IDOK2                           3
#define IDCANCEL2                       4
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_DBMSTYPE                    130
#define IDI_ICON_TABLE                  310
#define IDI_ICON_DATA                   311
#define IDD_FIELDDLG                    313
#define IDD_DB_TBNAMEDLG                317
#define IDD_DB_TBRENAMEDLG              318
#define IDD_QUERYDLG                    319
#define IDD_ADDRECORD                   320
#define IDD_RECORDDLG                   321
#define IDD_SQLDLG                      322
#define IDD_USERDLG                     323
#define IDD_REGISTERDLG                 324
#define IDC_EDIT1                       1000
#define IDC_EDIT3                       1002
#define IDC_CHECK1                      1003
#define IDC_CHECK2                      1004
#define IDC_EDIT4                       1005
#define IDC_EDIT5                       1006
#define IDC_COMBO1                      1007
#define IDC_EDIT6                       1008
#define IDC_BUTTON1                     1009
#define IDC_BUTTON2                     1010
#define IDC_EDIT2                       1011
#define IDC_STATIC1                     1014
#define IDC_LIST1                       1015
#define IDC_COMBO2                      1016
#define IDC_RADIO1                      1017
#define IDC_RADIO2                      1018
#define IDC_STATICQ                     1019
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_I                            32790
#define ID_SYS_INIT                     32791
#define ID_DATA_ADD                     32792
#define ID_DATA                         32793
#define ID_DATA_OPEN                    32794
#define ID_DATA_                        32795
#define ID_DATA_BACKUP                  32796
#define ID_DATA_RNAME                   32797
#define ID_DATA_DELETE                  32798
#define ID_TABLE_ADD                    32799
#define ID_TABLE_SELECT                 32800
#define ID_TABLE_SHOEALL                32801
#define ID_TABLE_                       32802
#define ID_TABLE_EMPTY                  32803
#define ID_TABLE_DELETE                 32804
#define ID_                             32805
#define ID_FIELD_ADD                    32806
#define ID_FILED_UODATE                 32807
#define ID_FILED_UPDATE                 32808
#define ID_FILED_DELETE                 32809
#define ID_RECORD_ADD                   32810
#define ID_RECORD_UPDATE                32811
#define ID_RECORD_ROLLBACK              32812
#define ID_RECORD_DELETE                32813
#define ID_TABLE_SHOWALL                32814
#define ID_TABLE_SHOW                   32815
#define ID_FIELD_UPDATE                 32816
#define ID_FIELD_DELETE                 32817
#define ID_32818                        32818
#define ID_FIELD_RENAME                 32819
#define ID_TABLE_RENAME                 32820
#define ID_32821                        32821
#define ID_SYSTEM_SQL                   32822

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32823
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           325
#endif
#endif
